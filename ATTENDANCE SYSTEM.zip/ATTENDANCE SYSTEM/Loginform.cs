﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace ATTENDANCE_SYSTEM
{
    public partial class Loginform : Form

    {
        SqlClientPermission  connect = new SqlClientPermissionAttribute.(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Cybel Salgado\OneDrive\Documents\database att.mdf;Integrated Security=True;Connect Timeout=30");
        public Loginform()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void loginBtn1_Click(object sender, EventArgs e)
        {
            if (username.Text == "" || password.Text == "")
            {
                MessageBox.Show("Please fill all blank fields", "Error Message" , MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                String selectData = "SELECT * FORM users WHERE username = @username AND passord @password";

                
            }
            


        }

        private void showPass_CheckedChanged(object sender, EventArgs e)
        {
            password.PasswordChar = showPass.Checked ? '\0' : '*';
        }
    }
}
