﻿namespace ATTENDANCE_SYSTEM
{
    partial class Loginform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label5 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            showPass = new CheckBox();
            loginBtn1 = new Button();
            password = new TextBox();
            label4 = new Label();
            username = new TextBox();
            label3 = new Label();
            label2 = new Label();
            panel3 = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(804, 50);
            panel1.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Cursor = Cursors.Hand;
            label5.Font = new Font("Stencil", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(760, 15);
            label5.Name = "label5";
            label5.Size = new Size(21, 21);
            label5.TabIndex = 1;
            label5.Text = "X";
            label5.Click += label5_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Stencil", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(310, 24);
            label1.TabIndex = 0;
            label1.Text = "NCIANS ATTENDANCE SYSTEM";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Turquoise;
            panel2.Controls.Add(showPass);
            panel2.Controls.Add(loginBtn1);
            panel2.Controls.Add(password);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(username);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(255, 67);
            panel2.Name = "panel2";
            panel2.Size = new Size(292, 365);
            panel2.TabIndex = 1;
            // 
            // showPass
            // 
            showPass.AutoSize = true;
            showPass.Location = new Point(142, 229);
            showPass.Name = "showPass";
            showPass.Size = new Size(132, 24);
            showPass.TabIndex = 6;
            showPass.Text = "Show Password";
            showPass.UseVisualStyleBackColor = true;
            showPass.CheckedChanged += showPass_CheckedChanged;
            // 
            // loginBtn1
            // 
            loginBtn1.BackColor = Color.Teal;
            loginBtn1.Cursor = Cursors.Hand;
            loginBtn1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginBtn1.ForeColor = SystemColors.ControlText;
            loginBtn1.Location = new Point(12, 283);
            loginBtn1.Name = "loginBtn1";
            loginBtn1.Size = new Size(262, 51);
            loginBtn1.TabIndex = 5;
            loginBtn1.Text = "LOGIN";
            loginBtn1.UseVisualStyleBackColor = false;
            loginBtn1.Click += loginBtn1_Click;
            // 
            // password
            // 
            password.Location = new Point(12, 185);
            password.Multiline = true;
            password.Name = "password";
            password.Size = new Size(262, 38);
            password.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(12, 152);
            label4.Name = "label4";
            label4.Size = new Size(104, 21);
            label4.TabIndex = 3;
            label4.Text = "PASSWORD:";
            // 
            // username
            // 
            username.Location = new Point(12, 90);
            username.Multiline = true;
            username.Name = "username";
            username.Size = new Size(262, 38);
            username.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(12, 57);
            label3.Name = "label3";
            label3.Size = new Size(102, 21);
            label3.TabIndex = 1;
            label3.Text = "USERNAME:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Stencil", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(99, 20);
            label2.Name = "label2";
            label2.Size = new Size(87, 24);
            label2.TabIndex = 0;
            label2.Text = "SIGN IN";
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(804, 458);
            panel3.TabIndex = 2;
            // 
            // Loginform
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 192);
            ClientSize = new Size(804, 458);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(panel3);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Loginform";
            Text = "Loginform";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Panel panel2;
        private Label label2;
        private Label label3;
        private Button loginBtn1;
        private TextBox password;
        private Label label4;
        private TextBox username;
        private Label label5;
        private CheckBox showPass;
        private Panel panel3;
    }
}